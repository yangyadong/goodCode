#!/bin/bash

echo "please input you email:"
read email

n=`echo $email | egrep "^[a-zA-Z0-9_-\.\+]+@[a-zA-Z_-\.]+(\.[a-zA-Z0-9_-]+)+$"|wc -l`

if [ $n == 0 ];then
	echo "Your input is invalid."
else
	echo "Your email address is $email"
fi