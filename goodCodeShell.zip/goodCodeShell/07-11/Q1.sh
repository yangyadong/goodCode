#!bin/base

#############################
#-Q1：用shell处理以下内容

#1、按单词出现频率降序排序！
#2、按字母出现频率降序排序！
#the squid project provides a number of resources toassist users design,implement and support squid installations. Please browsethe documentation and support sections for more infomation
#############################

gawk 'BEGIN{
    FS=" "
}
{
    arr=NF
    for (i=1; i<= arr; i++)
    {
        varr[$i]=varr[$i]+1
    }
}
END{
    for (test in varr)
    {
        print test,varr[test] | "sort -r -n -k2";
    }
}' $1
