#!bin/base

function demo(){
	if [ ! -d $2 ];then
		echo "path is not exist!create a folder? (yes or no):"
		read create
		if [ ${create} = "yes" ]; then
			mkdir $2
		else
			return 55
		fi
		wget -P $2 $1
		return 0;
	else
		wget -P $2 $1
		return 0;
	fi
}
read -p "please input url: " url;    
read -p "please input path: " path;    
demo $url $path;