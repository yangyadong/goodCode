#!bin/base

function demo(){
	if [ ! $# -eq 2 ]; then
        echo "参数个数不对"
	fi
	if [ ! -n "$(echo $1| sed -n "/^[0-9]\+$/p")" ]; then
		echo "num1 不是数字"
		return 0
	fi
	if [ ! -n "$(echo $2| sed -n "/^[0-9]\+$/p")" ]; then
		echo "num2 不是数字"
		return 0
	fi

	if [ $1 -ge $2 ]; then
		echo $1">"$2
	elif [ $1 -eq $2 ]; then
		echo $1"="$2
	else
		echo $1"<"$2
	fi
}
read -p "please input num1: " num1;    
read -p "please input num2: " num2;    
demo $num1 $num2;