#!bin/base

count=10
path="/home/j-huangyujing-ws/sh/shell/"
while [[ $count -ge 0 ]]; do
	name=`head -c 500 /dev/urandom | tr -dc a-z | head -c 5`
	createfile=${path}${name}"test.html"
	if [ ! -f $createfile ];then
		touch $createfile
		count=$((count - 1))
	fi
done
